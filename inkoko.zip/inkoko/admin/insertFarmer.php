<?php
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);
require '../php-includes/connect.php';
//require 'php-includes/check-login.php';

echo"welcome";

if(isset($_POST['save']))
{
  $names=$_POST['names'];
  $email=$_POST['email'];
  $phone=$_POST['phone'];
  $address=$_POST['address'];
  $password=md5($_POST['password']);
  $sql ="INSERT INTO farmer (email,names,phone,address,eggs,password) VALUES (?,?,?,?,'0',?)";
  $stm = $db->prepare($sql);

  if ($stm->execute(array($email,$names,$phone,$address,$password))) {
      print "<script>alert('Farmer added');window.location.assign('farmers.php')</script>";

  } else{
    echo $stm->errorCode();
     // echo "<script>alert('Error! try again');window.location.assign('farmers.php')</script>";
}
}
?>