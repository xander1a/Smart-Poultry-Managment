
<?php
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);
require '../php-includes/connect.php';
require 'php-includes/check-login.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Egg correction - store
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <!-- CSS Files -->
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="../assets/demo/demo.css" rel="stylesheet" />

  <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
</head>

<!DOCTYPE html>
<html>
<head>
    <title>Farmers Management</title>
    <!-- Include necessary CSS and JavaScript files here -->
</head>
<body class="">
    <?php require 'php-includes/nav.php';?>
    <div class="content">
        <div class="card card-plain">
            <div class="card-header">
                <h4 class="card-title">Farmers Management</h4>
            </div>
            <div class="card-body">
                <form name="search" method="post" action="sfarmers.php">
                    <div class="input-group no-border">
                        <input type="text" name="product" value="" class="form-control" placeholder="Search...">
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <button class="btn btn-facebook btn-block" type="submit" name="search">
                                    <i class="nc-icon nc-zoom-split"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
                <div class="table-responsive">
                    <table class="table">
                        <thead class="text-primary">
                            <th>Names</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Address</th>
                            <th>Eggs</th>
                            <th></th>
                        </thead>
                        <tbody>
                            <?php
                      // require '../php-includes/connect.php';
                            $sql = "SELECT * FROM farmer";
                            $stmt = $db->prepare($sql);
                            $stmt->execute();
                            if ($stmt->rowCount() > 0) {
                                $count = 1;
                                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                            ?>
                            <tr>
                                <td><?php echo $row['names'];?></td>
                                <td><?php echo $row['email'];?></td>
                                <td><?php echo $row['phone'];?></td>
                                <td><?php echo $row['address'];?></td>
                                <td><?php echo $row['eggs'];?></td>
                                <td>
                                    <form method="post">
                                        <button type="submit" class="btn btn-danger" name="delete" value="<?php echo $row["id"];?>">Delete</button>
                                    </form>
                                </td>
                            </tr>
                            <?php
                                $count++;
                                }
                            }
                            if(isset($_POST['delete'])){
                                $sid = $_POST['delete'];
                                $sql ="DELETE FROM farmer WHERE id = ?";
                                $stm = $db->prepare($sql);
                                if ($stm->execute(array($sid))) {
                                    echo "<script>alert('Farmer deleted');window.location.assign('farmers.php');</script>";
                                } else {
                                    echo "<script>alert('Fail');window.location.assign('farmers.php');</script>";
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="cols">
                        <div class="card card-user">
                            <div class="card-header">
                                <h5 class="card-title">Add new farmer</h5>
                            </div>
                            <div class="card-body">
                                <form method="post" action="insertFarmer.php">
                                    <div class="card-header py-6">
                                        <h6 class="m-0 font-weight-bold text-primary">Add new farmer</h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-group input-group">
                                            <span class="input-group-addon" style="width:150px;">Names:</span>
                                            <input type="text" style="width:350px;" class="form-control" name="names">
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon" style="width:150px;">Email:</span>
                                            <input type="email" style="width:350px;" class="form-control" name="email">
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon" style="width:150px;">Phone:</span>
                                            <input type="text" style="width:350px;" class="form-control" name="phone">
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon" style="width:150px;">Address:</span>
                                            <input type="text" style="width:350px;" class="form-control" name="address">
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon" style="width:150px;">Password:</span>
                                            <input type="password" style="width:350px;" class="form-control" name="password">
                                        </div>
                                        <button type="submit" class="btn btn-facebook btn-block" name="save">Add farmer</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    
                      </div>

                      <div class="cols">
                            <div class="card card-user">
                            <div class="row mb-3">
                          
            <div class="col-6">
                <input type="search" id="search-input" class="form-control" placeholder="Search">
            </div>
        </div>
        <table id="data-table" class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Quantinty</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Replace this with your actual data retrieval logic
                $sql = "SELECT * FROM ayatewe";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                if ($stmt->rowCount() > 0) {
                    $count = 1;
                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                ?>
                <tr>
                    <td><?php echo $count++; ?></td>
                    <td>1</td>
                    <td><?php echo $row['date']; ?></td>
                </tr>
                <?php
                    }
                }
                ?>
            </tbody>
        </table>
    </div>

                            </div>
                       </div>


                </div>
            </div>
        </div>
    </div>
  
    <!-- Include necessary JavaScript files here -->


  <!--   Core JS Files   -->
  <script src="../assets/js/core/jquery.min.js"></script>
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="../assets/js/core/bootstrap.min.js"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chart JS -->
  <script src="../assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="../assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script><!-- Paper Dashboard DEMO methods, don't include it in your project! -->
  <script src="../assets/demo/demo.js"></script>

  <script>
        $(document).ready(function () {
            var table = $('#data-table').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": true, // Enable searching
                "ordering": true,
                "info": true,
                "autoWidth": false
            });

            $('#search-input').on('keyup', function () {
                table.search(this.value).draw();
            });
        });
    </script>
</body>

</html>