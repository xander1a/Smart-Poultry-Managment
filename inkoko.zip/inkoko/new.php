<?php
// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize user inputs
    // $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    // $message = filter_input(INPUT_POST, 'message', FILTER_SANITIZE_STRING);



   // $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['message'];


    // Check if the email is valid
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Database connection parameters
        $host = "locahost";
        $username = "root";
        $password = "";
        $database = "poultry_system";

        try {
            // Create a PDO database connection
            $db = new PDO("mysql:host=$host;dbname=$database", $username, $password);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // SQL query to insert data into a table (assuming you have a 'messages' table)
            $sql = "INSERT INTO messages (email, message) VALUES (:email, :message)";
            
            // Prepare and execute the SQL query
            $stmt = $db->prepare($sql);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':message', $message);
            
            if ($stmt->execute()) {
                echo "Data inserted successfully!";
            } else {
                echo "Error: " . $stmt->errorInfo()[2];
            }

            // Close the database connection
            $db = null;
        } catch (PDOException $e) {
            echo "Database error: " . $e->getMessage();
        }
    }
     else {
        echo "Invalid email address.";
    }
}
?>
