<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require 'php-includes/connect.php';
use Yvesniyo\IntouchSms\SmsSimple;

include_once("vendor/autoload.php");

// Get the current time in the desired format
$currentDateTime = date('H:i'); // Format: HH:MM

$staticTime = '11:35';

$sql = "SELECT COUNT(*) AS count FROM ayatewe WHERE state = 6";
$stmt = $db->query($sql);
$count = $stmt->fetchColumn();


    echo "Total Sum: " . $count;

    $messi = "Number of eggs today: $count.";
    $sms = new SmsSimple();
    $sms->recipients(["0788575300"])
        ->message($messi)
        ->sender("+250783159293")
        ->username("dushime")
        ->password("dushime1")
        ->apiUrl("www.intouchsms.co.rw/api/sendsms/.json")
        ->callBackUrl("");
    print_r($sms->send());


echo "NO new egg detected";
?>

<h2>Total Eggs today: <?php echo $count; ?></h2>
