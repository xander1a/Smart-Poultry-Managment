<?php
// Include your database connection script here
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start(); // Start the session
require '../php-includes/connect.php'; // Include your database connection script
//require 'php-includes/check-login.php';

// Fetch the farmer's information
$query = "SELECT * FROM farmer WHERE email = ? LIMIT 1";
$stmt = $db->prepare($query);
$stmt->execute(array($_SESSION['email']));
$rows = $stmt->fetch(PDO::FETCH_ASSOC);

if ($stmt->rowCount() > 0) {
    $farmer = $rows['id'];
}

if (isset($_POST['send'])) {
    // Retrieve form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $message = $_POST['messege'];

    // Prepare and execute the SQL query
    date_default_timezone_set('Africa/Kigali');
    $currentTime = date("D, d M Y H:i:s");

    $sql = "INSERT INTO requested (name, email, phone, message, date) VALUES (?, ?, ?, ?, ?)";
    $stmt = $db->prepare($sql);

    // Bind parameters using bindParam
    $stmt->bindParam(1, $name);
    $stmt->bindParam(2, $email);
    $stmt->bindParam(3, $phone);
    $stmt->bindParam(4, $message);
    $stmt->bindParam(5, $currentTime);

    if ($stmt->execute()) {
        echo "Data inserted successfully";
    } else {
        echo "Error: " . $stmt->errorInfo()[2]; // Get the error message
    }

    // Close the database connection
    $stmt = null; // Release the statement
    $db = null; // Close the database connection
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Egg correction - request
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!-- Fonts and icons -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <!-- CSS Files -->
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="../assets/demo/demo.css" rel="stylesheet" />
</head>
<body class="">
<?php require 'php-includes/nav.php';?>
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="card card-plain">
                <div class="card-header">
                    <h4 class="card-title">Send request to Admin</h4>
                </div>
                <div class="card-body">
                    <?php
                    // Your existing code for displaying messages
                    ?>
                </div>
                <form method="post">
                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" class="form-control" name="name" value="<?php echo $rows['names']; ?>">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" class="form-control" name="email" value="<?php echo $rows['email']; ?>">
                    </div>
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="text" class="form-control" name="phone" value="<?php echo $rows['phone']; ?>">
                    </div>
                    <div class="form-group">
                        <label>Send message</label>
                        <input type="text" class="form-control" name="messege">
                    </div>
                    <div class="update ml-auto mr-auto">
                        <button type="submit" name="send" class="btn btn-primary btn-round">Send</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Your HTML footer and script includes go here -->
</body>
</html>
