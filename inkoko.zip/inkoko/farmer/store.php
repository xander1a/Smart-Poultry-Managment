<?php
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);
require '../php-includes/connect.php';
require 'php-includes/check-login.php';
$query = "SELECT * FROM farmer WHERE email= ? limit 1";
$stmt = $db->prepare($query);
$stmt->execute(array($_SESSION['email']));
$rows = $stmt->fetch(PDO::FETCH_ASSOC);
if ($stmt->rowCount()>0) {
    $farmer=$rows['id'];
    $totaleggs=$rows['eggs'];
}
if(isset($_POST['add'])){
  echo $amount=$_POST['egg'];
  echo $newbalance=$totaleggs+$amount;
      $sql ="UPDATE farmer SET eggs = ? WHERE email = ? limit 1";
      $stm = $db->prepare($sql);
      if ($stm->execute(array($newbalance, $_SESSION['email']))) {
          $sql ="INSERT INTO eggs (farmer, debit, total) VALUES (?,?,?)";
          $stm = $db->prepare($sql);
          $stm->execute(array($farmer,$amount,$newbalance));
          print "<script>alert('Eggs added');window.location.assign('store.php')</script>";
  
      } else{
      echo "<script>alert('Fail');window.location.assign('store.php')</script>";
  }
}
if(isset($_POST['remove'])){
    $amount=$_POST['eggs'];
    $newbalance=$totaleggs-$amount;
    if ($amount <= $totaleggs){
        $sql ="UPDATE farmer SET eggs = ? WHERE email = ? limit 1";
        $stm = $db->prepare($sql);
        if ($stm->execute(array($newbalance, $_SESSION['email']))) {
            $sql ="INSERT INTO eggs (farmer,credit,total) VALUES (?,?,?)";
            $stm = $db->prepare($sql);
            $stm->execute(array($farmer,$amount,$newbalance));
            print "<script>alert('Eggs removed');window.location.assign('store.php')</script>";
    
        }
    } else{
        echo "<script>alert('You have low number');window.location.assign('store.php')</script>";
    }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../assets/img/favicon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Egg Correction - Store</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.16/dist/tailwind.min.css" rel="stylesheet">
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <link href="../assets/demo/demo.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
</head>
<body class="bg-light">
    <?php require 'php-includes/nav.php'; ?>
    <div class="container mt-3">
        <div class="row">
            <div class="col-md-12">
                <h3>Total: <b><?php echo $totaleggs; ?></b> Eggs</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 mb-3">
                <div class="card card-user">
                    <div class="card-body">
                        <form method="post">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Enter number</label>
                                        <input type="number" class="form-control" name="egg">
                                    </div>
                                    <div class="update ml-auto mr-auto">
                                        <button type="submit" name="add" class="btn btn-primary btn-block">Add Eggs</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mb-3">
                <div class ="card card-user">
                    <div class="card-body">
                        <form method="post">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Enter number</label>
                                        <input type="number" class="form-control" name="eggs">
                                    </div>
                                    <div class="update ml-auto mr-auto">
                                        <button type="submit" name="remove" class="btn btn-primary btn-block">Remove Eggs</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
</div>

<div class="row">
        <div class="col-md-12">
            <div class="card card-plain">
              <div class="card-header">
                <h4 class="card-title">Store management</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                      <th>
                        Debit
                      </th>
                      <th>
                        Credit
                      </th>
                      <th>
                        Total
                      </th>
                      <th>
                        Time
                      </th>
                    </thead>
                    <tbody>
                    <?php
                    $query = "SELECT * FROM farmer WHERE email= ? limit 1";
                    $stmt = $db->prepare($query);
                    $stmt->execute(array($_SESSION['email']));
                    $rows = $stmt->fetch(PDO::FETCH_ASSOC);
                    if ($stmt->rowCount()>0) {
                        $id=$rows['id'];
                    }
                    $sql = "SELECT * FROM eggs WHERE farmer=?";
                    $stmt = $db->prepare($sql);
                    $stmt->execute(array($id));
                    if ($stmt->rowCount() > 0) {
                        $count = 1;
                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        ?>
                      <tr>
                        <td>
                        <?php echo $row['debit'];?>
                        </td>
                        <td>
                        <?php echo $row['credit'];?>
                        </td>
                        <td>
                        <?php echo $row['total'];?>
                        </td>
                        <td>
                        <?php echo $row['time'];?>
                        </td>
                      </tr>
                      <?php
                        $count++;
                        }
                    }
                    if(isset($_POST['delete'])){
                        $sql ="DELETE FROM buyers_mess WHERE id = ?";
                        $stm = $db->prepare($sql);
                        if ($stm->execute(array($sid))) {
                            print "<script>alert('Order removed');window.location.assign('sales.php')</script>";
                
                        } else {
                            print "<script>alert('Fail');window.location.assign('sales.php')</script>";
                        }
                    }
                    ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>
    </div>
</div>
<!-- Include other JS files if needed -->
</body>
</html>

<!-- JavaScript for Search Functionality -->
<script>
    const searchInput = document.getElementById('search');
    const tableBody = document.getElementById('table-body');

    searchInput.addEventListener('input', () => {
        const searchValue = searchInput.value.toLowerCase();
        const rows = tableBody.querySelectorAll('tr');

        rows.forEach((row) => {
            const columns = row.querySelectorAll('td');
            let found = false;

            columns.forEach((column) => {
                const text = column.textContent.toLowerCase();
                if (text.includes(searchValue)) {
                    found = true;
                }
            });

            if (found) {
                row.style.display = '';
            } else {
                row.style display = 'none';
            }
        });
    });
</script>
