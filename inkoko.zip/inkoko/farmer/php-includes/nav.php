<?php
$query = "SELECT * FROM farmer WHERE email= ? limit 1";
$stmt = $db->prepare($query);
$stmt->execute(array($_SESSION['email']));
$rows = $stmt->fetch(PDO::FETCH_ASSOC);
if ($stmt->rowCount()>0) {
    $names=$rows['names'];
}
?>
<div class="wrapper ">
    <div class="sidebar" data-color="white" data-active-color="danger">
      <div class="logo">
        <a href="#" class="simple-text logo-mini">
          <div class="logo-image-small">
            <img src="../assets/img/logo-small.png">
          </div>
        </a>
        <a href="dashboard.php" class="simple-text logo-normal">
          <?php echo $names;?>
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="active">
            <a href="dashboard.php">
              <i class="nc-icon nc-bank"></i>
              <p>Dashboard</p>
            </a>
          </li>
          <li>
            <a href="store.php">
              <i class="nc-icon nc-cart-simple"></i>
              <p>Store</p>
            </a>
          </li>
          <li>
            <a href="poultry.php">
              <i class="nc-icon nc-bank"></i>
              <p>poultry</p>
            </a>
          </li>

          <!--<li>
            <a href="request.php">
              <i class="nc-icon nc-bank"></i>
              <p>Request</p>
            </a>
          </li>-->

          <li>
            <a href="report.php">
              <i class="nc-icon nc-bank"></i>
              <p>Report</p>
            </a>
          </li>
          <li>
            <a href="help.php">
              <i class="nc-icon nc-chat-33"></i>
              <p>Help</p>
            </a>
          </li>
          <li>
            <a href="sales.php">
              <i class="nc-icon nc-paper"></i>
              <p>Sales</p>
            </a>
          </li>
          <li>
          <li>
            <a href="tec.php">
              <i class="nc-icon nc-paper"></i>
              <p>Technicians</p>
            </a>
          </li>
          <li>

          <li>
            <a href="vet.php">
              <i class="nc-icon nc-paper"></i>
              <p>veterianary</p>
            </a>
          </li>

          <li>
            <a href="food.php">
              <i class="nc-icon nc-paper"></i>
              <p>Food supplier</p>
            </a>
          </li>
          <li>
          <li>
            <a href="profile.php">
              <i class="nc-icon nc-single-02"></i>
              <p>Profile</p>
            </a>
          </li>
          <li>
            <a href="../php-includes/logout.php">
              <i class="nc-icon nc-button-power"></i>
              <p>Logout</p>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <div class="navbar-toggle">
              <button type="button" class="navbar-toggler">
                <span class="navbar-toggler-bar bar1"></span>
                <span class="navbar-toggler-bar bar2"></span>
                <span class="navbar-toggler-bar bar3"></span>
              </button>
            </div>
            <!-- <a class="navbar-brand" href="javascript:;">Poultry system</a> -->
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navigation">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link btn-rotate" href="../php-includes/logout.php">
                <i class="nc-icon nc-button-power"></i>
                  <p>
                    <span class="d-lg-none d-md-block">Logout</span>
                  </p>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>