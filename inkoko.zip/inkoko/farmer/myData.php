<!-- <?php

// require 'php-includes/connect.php';
// $tableName = "ayatewe";

// $sql = "DESCRIBE $tableName";

// $result = $db->query($sql);

// if ($result->rowCount() > 0) {
//     $numColumns = $result->rowCount();
//     echo "The table '$tableName' has $numColumns columns.";
// } else {

//     echo "The table '$tableName' does not exist or has no columns.";

// }
//?> -->
<?php
// Database connection parameters
require '../php-includes/connect.php';

// $tableName = "ayatewe";

// // SQL query to get the table structure
// $sql = "SELECT * FROM $tableName"; // You can replace this query with your specific query

// $result = $db->query($sql);

// if ($result !== false) {
//     $numRows = $result->rowCount();
//     echo "The result set has $numRows rows.";
// } else {
//     echo "An error occurred while executing the query.";
// }



$sql = "SELECT COUNT(*) AS count FROM ayatewe WHERE state = 0";

    $stmt = $db->query($sql);
    $count = $stmt->fetchColumn();
    echo "Number of rows with state equal to 0: " . $count;






?>
