#  Egg correction MIS
Project will helps to monitor the quantity of eggs and send sms when new egg detected in hen house and connect famer with buyers.

# Setup
To set up this project is easy, Just clone it from github.
## Import database 
import the sql file which is located under `/db/poultry_system.sql`

# Contributing
Contributions are welcome!
