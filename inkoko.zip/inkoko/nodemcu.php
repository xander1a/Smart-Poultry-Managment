<?php
require 'php-includes/connect.php';

// Initialize the response array
$response = array();
$receivedData = file_get_contents('php://input');
file_put_contents('received_data.log', $receivedData);

$data = json_decode($receivedData, true);
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($receivedData)) {
    if (isset($data['sendval']) && isset($data['sendval2']) ) {
        // Extract the values
        $val2 = $data['sendval'];
        $val3 = $data['sendval2'];
 
        $farmer = '1';
        date_default_timezone_set('Africa/Kigali'); // Set the time zone to Rwanda
        $currentDate = date('Y-m-d H:i:s'); // Format the date and time

        try {
            if ($val3 == 1) {
                // Fetch data from the "ayatewe" table
                $sql = "SELECT COUNT(*) AS count FROM ayatewe WHERE state = 6";
                $stmt = $db->query($sql);
                $count = $stmt->fetchColumn();

                // Fetch data from the "farmer" table
                $query = "SELECT * FROM farmer WHERE id = ? LIMIT 1";
                $stmt = $db->prepare($query);
                $stmt->execute(array($farmer)); // Assuming $farmer contains the farmer's ID
                $rows = $stmt->fetch(PDO::FETCH_ASSOC);
                $farmer=$rows['id'];

                if ($stmt->rowCount() > 0) {
                   
                    $totaleggs = $rows['eggs'];

                    $amagiMashya = $totaleggs + $count;

                    // Update eggs count in the "farmer" table
                    $sql = "UPDATE farmer SET eggs = ? WHERE id = ? LIMIT 1";
                    $stmt = $db->prepare($sql);
                    if ($stmt->execute(array($amagiMashya, $farmer))) {
                        // Insert a record into the "eggs" table
                        $sql = "INSERT INTO eggs (farmer, debit, total) VALUES (?, ?, ?)";
                        $stmt = $db->prepare($sql);
                        if ($stmt->execute(array($farmer, $count, $amagiMashya))) {
                            $response['update_success'] = true;
                            $response['insert_message'] = "Data updated and inserted successfully.";



                            $sqlDelete = "DELETE FROM ayatewe";
                $stmtDelete = $db->prepare($sqlDelete);
                if ($stmtDelete->execute()) {
                    $response['delete_success'] = true;
                    $response['delete_message'] = "All data deleted successfully.";
                } else {
                    $response['delete_success'] = false;
                    $response['delete_message'] = "Error deleting data: " . $stmtDelete->errorInfo()[2];
                }
                        }
                        
                        
                        else {
                            $response['update_success'] = false;
                            $response['insert_message'] = "Error inserting data into 'eggs': " . implode(', ', $stmt->errorInfo());
                        }
                    } else {
                        $response['update_success'] = false;
                        $response['insert_message'] = "Error updating data in 'farmer': " . implode(', ', $stmt->errorInfo());
                    }
                } else {
                    $response['update_success'] = false;
                    $response['insert_message'] = "No matching farmer found.";
                }
            } else {
                // Insert data into the "ayatewe" table
                $sqlInsert = "INSERT INTO ayatewe (state, count, date) VALUES (:val3, :val2, :val4)";
                $stmtInsert = $db->prepare($sqlInsert);
                $stmtInsert->bindValue(':val2', $val2);
                $stmtInsert->bindValue(':val3', $val3);
                $stmtInsert->bindValue(':val4', $currentDate);

                if ($stmtInsert->execute()) {
                    $response['insert_success'] = true;
                    $response['insert_message'] = "Data inserted successfully.";
                } else {
                    $response['insert_success'] = false;
                    $response['insert_message'] = "Error inserting data into 'ayatewe': " . implode(', ', $stmtInsert->errorInfo());
                }
            }
        } catch (PDOException $e) {
            $response['success'] = false;
            $response['message'] = "Database error: " . $e->getMessage();
        }
    } else {
        $response['success'] = false;
        $response['message'] = "Missing keys 'sendval', 'sendval2', or 'sendval3' in JSON data.";
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request or missing JSON data.";
}

// Do not close the database connection here

// Return a JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
